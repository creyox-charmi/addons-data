# -*- coding: utf-8 -*-
# Part of Creyox Technologies
import re

from odoo import http
from odoo.http import request
from odoo.addons.website_blog.controllers.main import WebsiteBlog
from odoo.addons.http_routing.models.ir_http import slug, unslug

class CrWebsiteBlog(WebsiteBlog):

    @http.route([
        '/blog',
        '/blog/page/<int:page>',
        '/blog/tag/<string:tag>',
        '/blog/tag/<string:tag>/page/<int:page>',
        '''/blog_post/all''',
        '''/blog/<model("blog.tag"):tags>''',
        '''/blog/<model("blog.blog"):blog>''',
        '''/blog/<model("blog.blog"):blog>/page/<int:page>''',
        '''/blog/<model("blog.blog"):blog>/tag/<string:tag>''',
        '''/blog/<model("blog.blog"):blog>/tag/<string:tag>/page/<int:page>''',
        # Add your new route here
        '/blog/featured',  # Example: New route for featured blog posts
        '/blog/featured/page/<int:page>',  # Paginated featured blogs
    ], type='http', auth="public", website=True, sitemap=True)
    def blog(self, blog=None, tag=None, page=1, search=None, **opt):
        response = super(CrWebsiteBlog, self).blog(blog, tag, page, search, **opt)
        print("opt : ",opt)
        if opt.get('tags'):
           print('>>',opt.get('tags'))
           print('response : ',response.get_data(as_text=True))

        return response


    def _prepare_blog_values(self, blogs, blog=False, date_begin=False, date_end=False, tags=False, state=False, page=False, search=None):
        print("before")
        ref = super(CrWebsiteBlog,self)._prepare_blog_values(blogs, blog, date_begin, date_end, tags, state, page, search)
        print("ref : ",ref)
        url_path = request.httprequest.path
        print("URL Path:", url_path)

        # Regular expression to capture the slug and id (slug-id pattern)
        match = re.search(r'/blog/([^/]+)-(\d+)', url_path)
        print("match : ",match)

        if match:
            slug_name = match.group(1)  # Extract the slug
            blog_id = match.group(2)  # Extract the ID
            print("Extracted Slug:", slug)
            print("Extracted ID:", blog_id)
            tag_list = request.env['blog.tag'].search([
                ('id','=',blog_id),
                ('name', '=', slug_name)
            ])
            print("tag_list : ", tag_list)
            ref['tag_list'] = tag_list
            ref['no_of_record_display'] = len(tag_list.post_ids)
            ref['is_latest_post'] = False
        elif url_path == '/blog_post/all':
            ref['tag_list'] = None
            print("len(ref('posts')) : ",len(ref['posts']))
            ref['no_of_record_display'] = len(ref['posts'])
            ref['is_latest_post'] = True
        else:
            tag_list = request.env['blog.tag'].search([])
            print("tag_list : ", tag_list)
            ref['tag_list'] = tag_list
            ref['no_of_record_display'] = 6
            ref['is_latest_post'] = True
            print("No matching pattern found in the URL.")

        print(f"slug_name: {slug_name}, ID: {blog_id}" if match else "No matching pattern found.")

        return ref

    @http.route(['/cr/blog/tag/<model("blog.tag"):tag>'], type='http', auth="public", website=True)
    def blog_tag_page(self, tag, **kw):
        # Fetch all blog posts associated with the selected tag
        blog_tag = request.env['blog.tag'].search([('id', '=', tag.id)])
        print(blog_tag)

        return request.redirect("/blog/%s" % (slug(blog_tag)))

    @http.route(['/cr/blog/tag/Latest'], type='http', auth="public", website=True)
    def blog_tag_page_all(self, **kw):
        print("yesss")
        return request.redirect("/blog_post/all")





